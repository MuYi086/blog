const s="/assets/outside_04.UKI6e2QT.png";export{s as _};
