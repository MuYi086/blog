const s="/assets/outside_02.BYwzFCil.png",t="/assets/outside_03.mW0MqlDp.png";export{s as _,t as a};
